const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const { Database } = require('sqlite3');
const app= express();
const port= 3000;

app.use(express.json());
app.use(cors());

const db =mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'usersdb'
});

db.connect((err) =>{
    if(err) {
        console.error('Hiba a MySQL adatbázishoz való csatlakozáskor: ', err);
    }
    else {
        console.log('Sikeresen csatlakoztunk a MySQL adatbázishoz');
    }       
})

//POST végpont az adatok mentésére a users táblában 
app.post('/api/users',(req,res) =>{
    //adatok elérése
    const {firstName, lastName, city, address, phone, email, gender}= req.body;

    const sql = 'INSERT INTO users (firstName, lastName, city, address, phone, email, gender) VALUES(?,?,?,?,?,?,?)'
    db.query(sql, [firstName, lastName, city, address, phone, email, gender],
    function(err){
        if (err) {
            console.log(err);
            return res.status(500).json({error: "Hiba történt"});
        }
        else {
            res.status(200).send({message: 'Adatok sikeresen rögzítése', id: this.lastID,firstName, lastName, city, address, phone, email, gender});
        }
    })
})

//
app.get('/api/users', (req,res) =>{
   db.query(`SELECT * FROM users`, [], (err, records) =>{
    if(err) {
        console.error(err)
        return res.status(500).json({message: "Hiba történt"});
    }
    else {
        return res.status(200).json(records);
    }
   })
})

app.delete('/api/users/:id', (req,res) =>{
//AZ ID elérése az url paraméterből
const{id} = req.params;

db.query(`DELETE FROM users WHERE id = ?`, [id],
// callback függvény az esetleges törlési hibak kezelésére
function(err){
    if(err) {
        return res.status(500).send(err.message)
    }
    else {
        return res.status(200).json({message: 'Felhasználó sikeresen törölve'})
    }
})
})
//PUT BÉGPONT A TÁBLÁBAN 
app.put('/api/users/:id', (req,res) =>{
    const {id} = req.params;
    const {firstName, lastName, city, address, phone, email, gender} = req.body;
    const sql = `UPDATE users SET firstName = ?, lastName = ?, city = ?, address = ?, phone = ?, email  = ?, gender = ? WHERE id = ?`;
    db.query(sql, [firstName, lastName, city, address, phone, email, gender, id],
     function(err){
    if(err) {
        return res.status(500).send(err.message)
    }
    else {
        return res.status(200).json({message: 'Felhasználó sikeresen fRISSÍTVE', id, firstName, lastName, city, address, phone, email, gender});
    }
        }
    )
})




    app.listen(port, () => {
        console.log(`A szerver fut a http://localhost: ${port} címen`);
    })
